import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div>
        <h1>"I learned that Node.js is a JavaScript runtime used outside the browser, and it's essential for React development along with npm, which manages packages. Vite is a modern build tool that makes development faster with native modules and quick setup."</h1>
      </div>
    </>
  )
}

export default App

public class arithmeticOperatorsDPB{
    public static void main(String[] args){
        double num1 = 37, num2 = 12;
        System.out.println( num1 + " + " + num2 + " = " +(num1+num2));
        System.out.println( num1 + " - " + num2 + " = " +(num1-num2));
        System.out.println( num1 + " * " + num2 + " = " +(num1*num2));
        System.out.println( num1 + " / " + num2 + " = " +(num1/num2));
    }
}
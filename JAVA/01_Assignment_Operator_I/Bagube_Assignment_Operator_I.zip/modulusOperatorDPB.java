public class modulusOperatorDPB {

    public static void main(String[] args) {
        double num1 = 10, num2 = 2;
        if(num1%num2 !=0){
            System.out.println( num1 + " % " + num2 + " = " +(num1%num2));
        }else{
            System.out.println("Hello World");
        }
    }
}